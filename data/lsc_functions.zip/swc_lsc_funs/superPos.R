#' superposition of discharge, unit hydrograph
#' 
#' superposition of precipitation along unit hydrograph (to simulate Q from P)
#' 
#' @return Vector of streamflow values
#' @author Berry Boessenkool, \email{berry-b@@gmx.de}, July 2013
#' @seealso \code{\link{lsc}} where superPos is used, \code{\link{unitHydrograph}}
#' @keywords hplot ts
#' @export
#' @examples 
#' 
#' N <- c(9,5,2,14,1,3) # [mm/hour]
#' UH <- c(0, 0.1, 0.4, 0.3, 0.1, 0.1) # [1/h]
#' sum(UH) # sum must be 1
#' 
#' superPos(N, UH) # direct flow component from rainfall
#' 
#' SP <- data.frame(Prec=c(N, 0,0,0,0,0),
#'           P1=c( UH*N[1], 0,0,0,0,0),
#'           P2=c(0, UH*N[2], 0,0,0,0),
#'           P3=c(0,0, UH*N[3], 0,0,0),
#'           P4=c(0,0,0, UH*N[4], 0,0),
#'           P5=c(0,0,0,0, UH*N[5], 0),
#'           P6=c(0,0,0,0,0, UH*N[6] ),
#'           runoff=superPos(N, UH))
#' SP # SuperPosition
#' 
#' SPcum <- t( apply(SP[2:7], 1, cumsum) )
#' 
#' plot(N, type="h", col=2:7, lwd=3, xlim=c(1, 10), ylim=c(30,0), lend=1)
#' par(new=TRUE)
#' plot(1, type="n", ylim=c(0, 15), xlim=c(1, 10), axes=FALSE, ann=FALSE)
#' axis(4, las=1)
#' polygon(x=c(1:11, 11:1), y=c(SPcum[,1], rep(0, 11)), col=2)
#' for(i in 2:6) polygon(x=c(1:11, 11:1), y=c(SPcum[,i], rev(SPcum[,i-1])), col=i+1)
#' text(3.5, 1, "Shape of UH")
#' lines( superPos(N, UH), lwd=3)
#' 
#' @param P  Vector with precipitation values
#' @param UH Vector with discrete values of the Unit Hydrograph. 
#'           This can be any UH summing to one, not just the storage cascade model.
#' 
superPos <- function(
P,
UH)
{
added <- length(UH)-1
qsim <- rep(0, length(P)+added )
for(i in 1:length(P) ) qsim[i:(i+added)] <- P[i]*UH + qsim[i:(i+added)]
qsim
}

